// MCFT-CAP-09.S5 adapter from one Shadow-online claim to the unchanged CAP-04 canonical Tick.
// Boundary: reuse canonical A1/A2, B, optional eligible C, and F persistence/readback with the scheduler claim's existing lease/fence.
// H is read-only proof for C; no G, action, route, daemon, model activation, or new transaction family.

import type { Pool } from "pg";

import type { CanonicalObjectEnvelopeV1 } from "../../domain/twin_runtime/canonical_object_contracts_v1.js";
import { CAP05_RUNTIME_CONFIG_PURPOSE_V1 } from "../../domain/twin_runtime/feedback_runtime_config_v1.js";
import { DirectCap04ExecutionConfigResolverV1 } from "../../domain/twin_runtime/runtime_config_execution_view_v1.js";
import { PostgresFeedbackPersistenceRepositoryV1 } from "../../persistence/twin_runtime/postgres_feedback_persistence_repository_v1.js";
import { PostgresForecastResidualSourceV1 } from "../../persistence/twin_runtime/postgres_forecast_residual_source_v1.js";
import { Cap08FrozenEvidenceSourceV1 } from "./cap08_frozen_evidence_source_v1.js";
import { Cap05InheritedCap04ExecutionConfigResolverV1 } from "./cap05_inherited_cap04_execution_config_resolver_v1.js";
import {
  Cap05ForecastResidualOutcomeTickServiceV1,
  type Cap05ForecastResidualTickExecutionPortV1,
} from "./forecast_residual_outcome_tick_service_v1.js";
import { PrepareNextTickInputServiceV1 } from "./next_tick_input_service_v1.js";
import {
  Cap04ForecastScenarioSingleTickServiceV1,
  type Cap04SingleTickPersistencePortV1,
  type ExecuteCap04SingleTickInputV1,
  type ExecuteCap04SingleTickResultV1,
} from "./forecast_scenario_single_tick_service_v1.js";
import { PostgresFrozenShadowOnlineEvidenceSourceV1 } from "./postgres_frozen_shadow_online_evidence_source_v1.js";
import type {
  FrozenShadowOnlineEvidenceV1,
  RuntimeConfigRepositoryPortV1,
  RuntimeLeaseClaimV1,
  ShadowOnlineSlotClaimV1,
  TwinScopeKeyV1,
} from "./ports.js";

const SCOPE_FIELDS = [
  "tenant_id", "project_id", "group_id", "field_id", "season_id", "zone_id",
] as const;

function assertScopeV1(left: TwinScopeKeyV1, right: TwinScopeKeyV1, code: string): void {
  if (!SCOPE_FIELDS.every((field) => left[field] === right[field])) throw new Error(code);
}

function memberV1(
  members: readonly CanonicalObjectEnvelopeV1[],
  objectType: CanonicalObjectEnvelopeV1["object_type"],
): CanonicalObjectEnvelopeV1 {
  const matches = members.filter((item) => item.object_type === objectType);
  if (matches.length !== 1) throw new Error(`S5_CANONICAL_MEMBER_CARDINALITY:${objectType}`);
  return matches[0];
}

class ClaimBoundCap04PersistenceV1 implements Cap04SingleTickPersistencePortV1 {
  constructor(
    private readonly canonical: Cap04SingleTickPersistencePortV1,
    private readonly claim: ShadowOnlineSlotClaimV1,
  ) {}

  async acquireLease(
    requested: Omit<RuntimeLeaseClaimV1, "fencing_token">,
  ): Promise<RuntimeLeaseClaimV1> {
    assertScopeV1(requested, this.claim.boundary.scope, "S5_CANONICAL_LEASE_SCOPE_MISMATCH");
    if (requested.lease_owner !== this.claim.lease_owner) {
      throw new Error("S5_CANONICAL_LEASE_OWNER_MUST_EQUAL_SCHEDULER_CLAIM");
    }
    return {
      ...requested,
      fencing_token: this.claim.fencing_token,
    };
  }

  lookupARecordSet: Cap04SingleTickPersistencePortV1["lookupARecordSet"] =
    (key) => this.canonical.lookupARecordSet(key);
  commitARecordSet: Cap04SingleTickPersistencePortV1["commitARecordSet"] =
    (input) => this.canonical.commitARecordSet(input);
  readARecordSet: Cap04SingleTickPersistencePortV1["readARecordSet"] =
    (id) => this.canonical.readARecordSet(id);
  lookupScenarioSet: Cap04SingleTickPersistencePortV1["lookupScenarioSet"] =
    (key) => this.canonical.lookupScenarioSet(key);
  commitScenarioSet: Cap04SingleTickPersistencePortV1["commitScenarioSet"] =
    (input) => this.canonical.commitScenarioSet(input);
  readScenarioSet: Cap04SingleTickPersistencePortV1["readScenarioSet"] =
    (id) => this.canonical.readScenarioSet(id);
  readScenarioSetBySourceForecast: Cap04SingleTickPersistencePortV1["readScenarioSetBySourceForecast"] =
    (ref, hash) => this.canonical.readScenarioSetBySourceForecast(ref, hash);
  detectPendingScenario: Cap04SingleTickPersistencePortV1["detectPendingScenario"] =
    (scope) => this.canonical.detectPendingScenario(scope);
  rebuildForecastProjections: Cap04SingleTickPersistencePortV1["rebuildForecastProjections"] =
    (id) => this.canonical.rebuildForecastProjections(id);
  rebuildScenarioProjections: Cap04SingleTickPersistencePortV1["rebuildScenarioProjections"] =
    (id) => this.canonical.rebuildScenarioProjections(id);
}

class FixedCap04TickResultPortV1 implements Cap05ForecastResidualTickExecutionPortV1 {
  constructor(
    private readonly expected: ExecuteCap04SingleTickInputV1,
    private readonly result: ExecuteCap04SingleTickResultV1,
  ) {}

  async executeOneTick(input: ExecuteCap04SingleTickInputV1): Promise<ExecuteCap04SingleTickResultV1> {
    assertScopeV1(input.scope, this.expected.scope, "S5_C_RESIDUAL_TICK_SCOPE_MISMATCH");
    for (const field of [
      "logical_time",
      "runtime_config_ref",
      "runtime_config_hash",
      "lease_owner",
    ] as const) {
      if (input[field] !== this.expected[field]) {
        throw new Error(`S5_C_RESIDUAL_TICK_INPUT_MISMATCH:${field}`);
      }
    }
    return this.result;
  }
}

export type ExecuteShadowOnlineCanonicalTickInputV1 = {
  claim: ShadowOnlineSlotClaimV1;
  evidence: FrozenShadowOnlineEvidenceV1;
  canonical_input: ExecuteCap04SingleTickInputV1;
};

export type ExecuteShadowOnlineCanonicalTickResultV1 = {
  status: ExecuteCap04SingleTickResultV1["status"];
  canonical_transaction_families: readonly ("A" | "B" | "C" | "F")[];
  tick_ref: string;
  state_ref: string;
  forecast_ref: string;
  forecast_status: "COMPLETED" | "BLOCKED";
  forecast_point_count: 0 | 72;
  scenario_ref: string | null;
  scenario_option_count: 0 | 3;
  scenario_point_count: 0 | 216;
  health_ref: string;
  checkpoint_ref: string;
  next_logical_tick_time: string;
  h_read_only_consumed: boolean;
  g_write_count: 0;
  c_residual_attempted: boolean;
  c_residual_count: 0 | 1;
  c_residual_ref: string | null;
  c_residual_disposition:
    | "RUNTIME_CONFIG_NOT_CAP05"
    | "FORECAST_BLOCKED"
    | "NO_ELIGIBLE_HISTORICAL_FORECAST"
    | "COMMITTED";
  recommendation_count: 0;
  approval_count: 0;
  ao_act_count: 0;
  dispatch_count: 0;
  model_activation_count: 0;
};

export interface ShadowOnlineCanonicalTickPortV1 {
  executeOneTick(
    input: ExecuteShadowOnlineCanonicalTickInputV1,
  ): Promise<ExecuteShadowOnlineCanonicalTickResultV1>;
}

export class PostgresCap04ShadowOnlineCanonicalTickAdapterV1
implements ShadowOnlineCanonicalTickPortV1 {
  constructor(
    private readonly pool: Pool,
    private readonly handoff: PrepareNextTickInputServiceV1,
    private readonly runtimeConfig: RuntimeConfigRepositoryPortV1,
    private readonly canonicalPersistence: Cap04SingleTickPersistencePortV1,
  ) {}

  async executeOneTick(
    input: ExecuteShadowOnlineCanonicalTickInputV1,
  ): Promise<ExecuteShadowOnlineCanonicalTickResultV1> {
    assertScopeV1(
      input.canonical_input.scope,
      input.claim.boundary.scope,
      "S5_CANONICAL_INPUT_SCOPE_MISMATCH",
    );
    if (input.canonical_input.logical_time !== input.claim.boundary.logical_time) {
      throw new Error("S5_CANONICAL_INPUT_LOGICAL_TIME_MISMATCH");
    }
    if (input.canonical_input.lease_owner !== input.claim.lease_owner) {
      throw new Error("S5_CANONICAL_INPUT_LEASE_OWNER_MISMATCH");
    }
    if (input.evidence.boundary.logical_time !== input.claim.boundary.logical_time) {
      throw new Error("S5_FROZEN_EVIDENCE_BOUNDARY_MISMATCH");
    }

    const selectedSource = new PostgresFrozenShadowOnlineEvidenceSourceV1(
      this.pool,
      input.evidence,
    );
    const frozenSource = new Cap08FrozenEvidenceSourceV1(selectedSource);
    await frozenSource.freeze({
      scope: input.claim.boundary.scope,
      logical_time: input.claim.boundary.logical_time,
    });

    const canonicalConfig = await this.runtimeConfig.readRuntimeConfig(
      input.canonical_input.runtime_config_ref,
    );
    if (!canonicalConfig
      || canonicalConfig.object_type !== "twin_runtime_config_v1"
      || canonicalConfig.determinism_hash !== input.canonical_input.runtime_config_hash) {
      throw new Error("S5_CANONICAL_RUNTIME_CONFIG_MISMATCH");
    }
    const cap05Runtime = canonicalConfig.payload.config_purpose === CAP05_RUNTIME_CONFIG_PURPOSE_V1;
    const executionConfigResolver = cap05Runtime
      ? new Cap05InheritedCap04ExecutionConfigResolverV1()
      : new DirectCap04ExecutionConfigResolverV1();

    const claimBoundPersistence = new ClaimBoundCap04PersistenceV1(
      this.canonicalPersistence,
      input.claim,
    );
    const cap04Tick = new Cap04ForecastScenarioSingleTickServiceV1(
      this.handoff,
      frozenSource,
      this.runtimeConfig,
      claimBoundPersistence,
      executionConfigResolver,
    );
    const result = await cap04Tick.executeOneTick(input.canonical_input);
    if (frozenSource.getSourceLoadCount() !== 1) {
      throw new Error("S5_EXACT_ONE_FROZEN_EVIDENCE_SOURCE_LOAD_REQUIRED");
    }

    const members = result.a_record_set.members;
    const tick = memberV1(members, "twin_runtime_tick_v1");
    const state = memberV1(members, "twin_state_estimate_v1");
    const forecast = memberV1(members, "twin_forecast_run_v1");
    const health = memberV1(members, "twin_runtime_health_v1");
    const checkpoint = memberV1(members, "twin_runtime_checkpoint_v1");
    const forecastStatus = String(forecast.payload.status);
    if (forecastStatus !== "COMPLETED" && forecastStatus !== "BLOCKED") {
      throw new Error("S5_CANONICAL_FORECAST_TERMINAL_STATUS_REQUIRED");
    }
    const points = Array.isArray(forecast.payload.points) ? forecast.payload.points.length : 0;
    if ((forecastStatus === "COMPLETED" && points !== 72)
        || (forecastStatus === "BLOCKED" && points !== 0)) {
      throw new Error("S5_CANONICAL_FORECAST_POINT_CARDINALITY_MISMATCH");
    }

    const scenario = result.b_record?.scenario_set ?? null;
    const options = scenario?.payload.options ?? [];
    const scenarioPointCount = options.reduce<number>(
      (sum, option) => sum + option.trajectory_points.length,
      0,
    );
    if ((forecastStatus === "COMPLETED"
        && (options.length !== 3
          || options.some((option) => option.trajectory_points.length !== 72)))
        || (forecastStatus === "BLOCKED" && scenario !== null)) {
      throw new Error("S5_CANONICAL_SCENARIO_ELIGIBILITY_MISMATCH");
    }

    let residualAttempted = false;
    let residualCount: 0 | 1 = 0;
    let residualRef: string | null = null;
    let residualDisposition: ExecuteShadowOnlineCanonicalTickResultV1["c_residual_disposition"] =
      cap05Runtime ? "FORECAST_BLOCKED" : "RUNTIME_CONFIG_NOT_CAP05";
    let hReadOnlyConsumed = false;
    if (forecastStatus === "COMPLETED" && cap05Runtime) {
      residualAttempted = true;
      const residualService = new Cap05ForecastResidualOutcomeTickServiceV1(
        new FixedCap04TickResultPortV1(input.canonical_input, result),
        this.runtimeConfig,
        new PostgresForecastResidualSourceV1(this.pool),
        new PostgresFeedbackPersistenceRepositoryV1(this.pool),
      );
      try {
        const residual = await residualService.executeOneTickAndCommitResidual(
          input.canonical_input,
        );
        const selected = residual.forecast_selection_trace.entries.find(
          (entry) => entry.disposition === "SELECTED",
        );
        if (!selected || selected.source_posterior_action_feedback_refs.length === 0) {
          throw new Error("S5_C_RESIDUAL_REQUIRES_READ_ONLY_H_PROOF");
        }
        hReadOnlyConsumed = true;
        residualCount = 1;
        residualRef = residual.residual.object_id;
        residualDisposition = "COMMITTED";
      } catch (error) {
        if (!(error instanceof Error)
          || error.message !== "CAP05_FORECAST_RESIDUAL_MATCH_NOT_FOUND") {
          throw error;
        }
        residualDisposition = "NO_ELIGIBLE_HISTORICAL_FORECAST";
      }
    }

    const nextHandoff = await this.handoff.prepareNextTickInput(input.claim.boundary.scope);
    if (nextHandoff.previous_posterior_ref !== state.object_id
        || nextHandoff.previous_forecast_result_ref !== forecast.object_id
        || nextHandoff.previous_checkpoint_ref !== checkpoint.object_id) {
      throw new Error("S5_ONLINE_READBACK_POINTER_MISMATCH");
    }

    return {
      status: result.status,
      canonical_transaction_families: residualCount === 1
        ? ["A", "B", "C", "F"]
        : forecastStatus === "COMPLETED"
          ? ["A", "B", "F"]
          : ["A", "F"],
      tick_ref: tick.object_id,
      state_ref: state.object_id,
      forecast_ref: forecast.object_id,
      forecast_status: forecastStatus,
      forecast_point_count: points as 0 | 72,
      scenario_ref: scenario?.object_id ?? null,
      scenario_option_count: options.length as 0 | 3,
      scenario_point_count: scenarioPointCount as 0 | 216,
      health_ref: health.object_id,
      checkpoint_ref: checkpoint.object_id,
      next_logical_tick_time: nextHandoff.next_logical_tick_time,
      h_read_only_consumed: hReadOnlyConsumed,
      g_write_count: 0,
      c_residual_attempted: residualAttempted,
      c_residual_count: residualCount,
      c_residual_ref: residualRef,
      c_residual_disposition: residualDisposition,
      recommendation_count: 0,
      approval_count: 0,
      ao_act_count: 0,
      dispatch_count: 0,
      model_activation_count: 0,
    };
  }
}
