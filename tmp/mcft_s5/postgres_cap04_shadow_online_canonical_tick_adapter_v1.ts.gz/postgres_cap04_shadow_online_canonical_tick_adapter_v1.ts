// MCFT-CAP-09.S5 adapter from one Shadow-online claim to the unchanged CAP-04 canonical Tick.
// Boundary: reuse canonical A1/A2 and B persistence with the scheduler claim's existing lease/fence,
// then read the canonical F handoff. No G, action, route, daemon, model activation, or new transaction family.

import type { Pool } from "pg";

import type { CanonicalObjectEnvelopeV1 } from "../../domain/twin_runtime/canonical_object_contracts_v1.js";
import { Cap08FrozenEvidenceSourceV1 } from "./cap08_frozen_evidence_source_v1.js";
import {
  Cap04ForecastScenarioSingleTickServiceV1,
  type Cap04SingleTickPersistencePortV1,
  type ExecuteCap04SingleTickInputV1,
  type ExecuteCap04SingleTickResultV1,
} from "./forecast_scenario_single_tick_service_v1.js";
import { PostgresFrozenShadowOnlineEvidenceSourceV1 } from "./postgres_frozen_shadow_online_evidence_source_v1.js";
import type {
  FrozenShadowOnlineEvidenceV1,
  PreparedNextTickInputV1,
  RuntimeConfigRepositoryPortV1,
  RuntimeLeaseClaimV1,
  ShadowOnlineSlotClaimV1,
  TwinScopeKeyV1,
} from "./ports.js";

type EvidencePoolV1 = Pick<Pool, "query">;
type PrepareNextTickPortV1 = {
  prepareNextTickInput(scope: TwinScopeKeyV1): Promise<PreparedNextTickInputV1>;
};

const SCOPE_FIELDS = [
  "tenant_id", "project_id", "group_id", "field_id", "season_id", "zone_id",
] as const;

function assertScopeV1(left: TwinScopeKeyV1, right: TwinScopeKeyV1, code: string): void {
  if (!SCOPE_FIELDS.every((field) => left[field] === right[field])) throw new Error(code);
}

function memberV1(
  members: readonly CanonicalObjectEnvelopeV1[],
  objectType: CanonicalObjectEnvelopeV1["object_type"],
): CanonicalObjectEnvelopeV1 {
  const matches = members.filter((item) => item.object_type === objectType);
  if (matches.length !== 1) throw new Error(`S5_CANONICAL_MEMBER_CARDINALITY:${objectType}`);
  return matches[0];
}

class ClaimBoundCap04PersistenceV1 implements Cap04SingleTickPersistencePortV1 {
  constructor(
    private readonly canonical: Cap04SingleTickPersistencePortV1,
    private readonly claim: ShadowOnlineSlotClaimV1,
  ) {}

  async acquireLease(
    requested: Omit<RuntimeLeaseClaimV1, "fencing_token">,
  ): Promise<RuntimeLeaseClaimV1> {
    assertScopeV1(requested, this.claim.boundary.scope, "S5_CANONICAL_LEASE_SCOPE_MISMATCH");
    if (requested.lease_owner !== this.claim.lease_owner) {
      throw new Error("S5_CANONICAL_LEASE_OWNER_MUST_EQUAL_SCHEDULER_CLAIM");
    }
    return {
      ...requested,
      fencing_token: this.claim.fencing_token,
    };
  }

  lookupARecordSet: Cap04SingleTickPersistencePortV1["lookupARecordSet"] =
    (key) => this.canonical.lookupARecordSet(key);
  commitARecordSet: Cap04SingleTickPersistencePortV1["commitARecordSet"] =
    (input) => this.canonical.commitARecordSet(input);
  readARecordSet: Cap04SingleTickPersistencePortV1["readARecordSet"] =
    (id) => this.canonical.readARecordSet(id);
  lookupScenarioSet: Cap04SingleTickPersistencePortV1["lookupScenarioSet"] =
    (key) => this.canonical.lookupScenarioSet(key);
  commitScenarioSet: Cap04SingleTickPersistencePortV1["commitScenarioSet"] =
    (input) => this.canonical.commitScenarioSet(input);
  readScenarioSet: Cap04SingleTickPersistencePortV1["readScenarioSet"] =
    (id) => this.canonical.readScenarioSet(id);
  readScenarioSetBySourceForecast: Cap04SingleTickPersistencePortV1["readScenarioSetBySourceForecast"] =
    (ref, hash) => this.canonical.readScenarioSetBySourceForecast(ref, hash);
  detectPendingScenario: Cap04SingleTickPersistencePortV1["detectPendingScenario"] =
    (scope) => this.canonical.detectPendingScenario(scope);
  rebuildForecastProjections: Cap04SingleTickPersistencePortV1["rebuildForecastProjections"] =
    (id) => this.canonical.rebuildForecastProjections(id);
  rebuildScenarioProjections: Cap04SingleTickPersistencePortV1["rebuildScenarioProjections"] =
    (id) => this.canonical.rebuildScenarioProjections(id);
}

export type ExecuteShadowOnlineCanonicalTickInputV1 = {
  claim: ShadowOnlineSlotClaimV1;
  evidence: FrozenShadowOnlineEvidenceV1;
  canonical_input: ExecuteCap04SingleTickInputV1;
};

export type ExecuteShadowOnlineCanonicalTickResultV1 = {
  status: ExecuteCap04SingleTickResultV1["status"];
  canonical_transaction_families: readonly ("A" | "B" | "F")[];
  tick_ref: string;
  state_ref: string;
  forecast_ref: string;
  forecast_status: "COMPLETED" | "BLOCKED";
  forecast_point_count: 0 | 72;
  scenario_ref: string | null;
  scenario_option_count: 0 | 3;
  scenario_point_count: 0 | 216;
  health_ref: string;
  checkpoint_ref: string;
  next_logical_tick_time: string;
  h_read_only_consumed: false;
  g_write_count: 0;
  c_residual_count: 0;
  recommendation_count: 0;
  approval_count: 0;
  ao_act_count: 0;
  dispatch_count: 0;
  model_activation_count: 0;
};

export interface ShadowOnlineCanonicalTickPortV1 {
  executeOneTick(
    input: ExecuteShadowOnlineCanonicalTickInputV1,
  ): Promise<ExecuteShadowOnlineCanonicalTickResultV1>;
}

export class PostgresCap04ShadowOnlineCanonicalTickAdapterV1
implements ShadowOnlineCanonicalTickPortV1 {
  constructor(
    private readonly pool: EvidencePoolV1,
    private readonly handoff: PrepareNextTickPortV1,
    private readonly runtimeConfig: RuntimeConfigRepositoryPortV1,
    private readonly canonicalPersistence: Cap04SingleTickPersistencePortV1,
  ) {}

  async executeOneTick(
    input: ExecuteShadowOnlineCanonicalTickInputV1,
  ): Promise<ExecuteShadowOnlineCanonicalTickResultV1> {
    assertScopeV1(
      input.canonical_input.scope,
      input.claim.boundary.scope,
      "S5_CANONICAL_INPUT_SCOPE_MISMATCH",
    );
    if (input.canonical_input.logical_time !== input.claim.boundary.logical_time) {
      throw new Error("S5_CANONICAL_INPUT_LOGICAL_TIME_MISMATCH");
    }
    if (input.canonical_input.lease_owner !== input.claim.lease_owner) {
      throw new Error("S5_CANONICAL_INPUT_LEASE_OWNER_MISMATCH");
    }
    if (input.evidence.boundary.logical_time !== input.claim.boundary.logical_time) {
      throw new Error("S5_FROZEN_EVIDENCE_BOUNDARY_MISMATCH");
    }

    const selectedSource = new PostgresFrozenShadowOnlineEvidenceSourceV1(
      this.pool,
      input.evidence,
    );
    const frozenSource = new Cap08FrozenEvidenceSourceV1(selectedSource);
    await frozenSource.freeze({
      scope: input.claim.boundary.scope,
      logical_time: input.claim.boundary.logical_time,
    });

    const claimBoundPersistence = new ClaimBoundCap04PersistenceV1(
      this.canonicalPersistence,
      input.claim,
    );
    const cap04Tick = new Cap04ForecastScenarioSingleTickServiceV1(
      this.handoff,
      frozenSource,
      this.runtimeConfig,
      claimBoundPersistence,
    );
    const result = await cap04Tick.executeOneTick(input.canonical_input);
    if (frozenSource.getSourceLoadCount() !== 1) {
      throw new Error("S5_EXACT_ONE_FROZEN_EVIDENCE_SOURCE_LOAD_REQUIRED");
    }

    const members = result.a_record_set.members;
    const tick = memberV1(members, "twin_runtime_tick_v1");
    const state = memberV1(members, "twin_state_estimate_v1");
    const forecast = memberV1(members, "twin_forecast_run_v1");
    const health = memberV1(members, "twin_runtime_health_v1");
    const checkpoint = memberV1(members, "twin_runtime_checkpoint_v1");
    const forecastStatus = String(forecast.payload.status);
    if (forecastStatus !== "COMPLETED" && forecastStatus !== "BLOCKED") {
      throw new Error("S5_CANONICAL_FORECAST_TERMINAL_STATUS_REQUIRED");
    }
    const points = Array.isArray(forecast.payload.points) ? forecast.payload.points.length : 0;
    if ((forecastStatus === "COMPLETED" && points !== 72)
        || (forecastStatus === "BLOCKED" && points !== 0)) {
      throw new Error("S5_CANONICAL_FORECAST_POINT_CARDINALITY_MISMATCH");
    }

    const scenario = result.b_record?.scenario_set ?? null;
    const options = scenario?.payload.options ?? [];
    if ((forecastStatus === "COMPLETED"
        && (options.length !== 3
          || options.some((option) => option.trajectory_points.length !== 72)))
        || (forecastStatus === "BLOCKED" && scenario !== null)) {
      throw new Error("S5_CANONICAL_SCENARIO_ELIGIBILITY_MISMATCH");
    }

    const nextHandoff = await this.handoff.prepareNextTickInput(input.claim.boundary.scope);
    if (nextHandoff.previous_posterior_ref !== state.object_id
        || nextHandoff.previous_forecast_result_ref !== forecast.object_id
        || nextHandoff.previous_checkpoint_ref !== checkpoint.object_id) {
      throw new Error("S5_ONLINE_READBACK_POINTER_MISMATCH");
    }

    return {
      status: result.status,
      canonical_transaction_families: forecastStatus === "COMPLETED"
        ? ["A", "B", "F"]
        : ["A", "F"],
      tick_ref: tick.object_id,
      state_ref: state.object_id,
      forecast_ref: forecast.object_id,
      forecast_status: forecastStatus,
      forecast_point_count: points as 0 | 72,
      scenario_ref: scenario?.object_id ?? null,
      scenario_option_count: options.length as 0 | 3,
      scenario_point_count: options.reduce(
        (sum, option) => sum + option.trajectory_points.length,
        0,
      ) as 0 | 216,
      health_ref: health.object_id,
      checkpoint_ref: checkpoint.object_id,
      next_logical_tick_time: nextHandoff.next_logical_tick_time,
      h_read_only_consumed: false,
      g_write_count: 0,
      c_residual_count: 0,
      recommendation_count: 0,
      approval_count: 0,
      ao_act_count: 0,
      dispatch_count: 0,
      model_activation_count: 0,
    };
  }
}
