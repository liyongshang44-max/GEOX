// MCFT-CAP-09.S5 real PostgreSQL Shadow-online canonical integration acceptance.
// Destructive disposable-database only. Proves completed and blocked A/F paths,
// B eligibility, exact S2 frozen Evidence reuse, shared scheduler/canonical fence,
// terminal slot persistence, online readback, idempotent no-retry, and zero G/actions.

import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { Pool } from "pg";

import { PostgresForecastScenarioRecoveryRepositoryV1 } from "../../apps/server/src/persistence/twin_runtime/postgres_forecast_scenario_recovery_repository_v1.js";
import { PostgresRuntimeRepositoryV1 } from "../../apps/server/src/persistence/twin_runtime/postgres_runtime_repository_v1.js";
import { PostgresEvidenceIngressAdapterV1 } from "../../apps/server/src/runtime/twin_runtime/postgres_evidence_ingress_adapter_v1.js";
import { PostgresExpiredSlotRecoveryAdapterV1 } from "../../apps/server/src/runtime/twin_runtime/postgres_expired_slot_recovery_adapter_v1.js";
import {
  PostgresCap04ShadowOnlineCanonicalTickAdapterV1,
} from "../../apps/server/src/runtime/twin_runtime/postgres_cap04_shadow_online_canonical_tick_adapter_v1.js";
import {
  PostgresPersistentSequentialSchedulerAdapterV1,
} from "../../apps/server/src/runtime/twin_runtime/postgres_persistent_sequential_scheduler_adapter_v1.js";
import {
  RestartBackfillStaleDetectionServiceV1,
} from "../../apps/server/src/runtime/twin_runtime/restart_backfill_stale_detection_service_v1.js";
import {
  ShadowOnlineCanonicalIntegrationServiceV1,
} from "../../apps/server/src/runtime/twin_runtime/shadow_online_canonical_integration_service_v1.js";
import { PrepareNextTickInputServiceV1 } from "../../apps/server/src/runtime/twin_runtime/next_tick_input_service_v1.js";
import type { CanonicalReplayEvidenceRecordV1 } from "../../apps/server/src/runtime/twin_runtime/ports.js";
import {
  buildControlledAuthorityV1,
  persistenceAdapterV1,
  pool as supportPool,
  resetSchemaV1,
  seedControlledAuthorityV1,
} from "./mcft_cap09_s5_canonical_integration_support_v1.js";

if (process.env.MCFT_CAP09_S5_DESTRUCTIVE_ACCEPTANCE !== "1") {
  throw new Error("SET_MCFT_CAP09_S5_DESTRUCTIVE_ACCEPTANCE_1");
}
const databaseUrl = String(process.env.DATABASE_URL || "");
if (!databaseUrl) throw new Error("DATABASE_URL_REQUIRED");
const databaseName = new URL(databaseUrl).pathname.replace(/^\//, "").toLowerCase();
if (!/(mcft|cap09|s5|acceptance|test)/.test(databaseName)) {
  throw new Error("CAP09_S5_FRESH_ACCEPTANCE_DATABASE_REQUIRED");
}

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const OUTPUT = path.join(
  ROOT,
  "acceptance-output/MCFT_CAP_09_S5_SHADOW_ONLINE_CANONICAL_INTEGRATION_DB_RESULT.json",
);
const pool = new Pool({ connectionString: databaseUrl, max: 8 });

function factIdV1(record: CanonicalReplayEvidenceRecordV1): string {
  return `s5_evidence_${crypto.createHash("sha256")
    .update(`${record.source_record_id}|${record.source_record_hash}`)
    .digest("hex")
    .slice(0, 40)}`;
}

async function applySchedulerMigrationV1(): Promise<void> {
  const sql = fs.readFileSync(
    path.join(
      ROOT,
      "apps/server/db/migrations/2026_08_06_mcft_cap_09_s3_persistent_sequential_scheduler.sql",
    ),
    "utf8",
  );
  await pool.query(sql);
}

async function insertEvidenceV1(
  records: readonly CanonicalReplayEvidenceRecordV1[],
): Promise<void> {
  for (const record of records) {
    await pool.query(
      `INSERT INTO facts(fact_id,occurred_at,source,record_json)
       VALUES($1,$2::timestamptz,$3,$4::jsonb)`,
      [
        factIdV1(record),
        record.available_to_runtime_at,
        "mcft-cap09-s5-shadow-online-acceptance",
        JSON.stringify({ type: record.record_type, payload: record }),
      ],
    );
  }
}

async function factObjectCountV1(objectId: string): Promise<number> {
  const result = await pool.query<{ n: number }>(
    `SELECT count(*)::int AS n
       FROM facts
      WHERE record_json->'payload'->>'object_id'=$1`,
    [objectId],
  );
  return Number(result.rows[0].n);
}

async function forbiddenFactCountV1(): Promise<number> {
  const result = await pool.query<{ n: number }>(
    `SELECT count(*)::int AS n
       FROM facts
      WHERE lower(record_json->>'type') ~
        '(recommendation|decision_candidate|approval|operation_plan|ao_act|dispatch|action_feedback|model_activation)'`,
  );
  return Number(result.rows[0].n);
}

async function factCountV1(): Promise<number> {
  return Number((await pool.query<{ n: number }>(
    "SELECT count(*)::int AS n FROM facts",
  )).rows[0].n);
}

async function schedulerTerminalV1(): Promise<Record<string, unknown>> {
  const result = await pool.query(
    `SELECT slot_id,state,tick_ref,health_ref,idempotency_key,fencing_token
       FROM twin_shadow_online_scheduler_slot_v1
      ORDER BY logical_time`,
  );
  assert.equal(result.rows.length, 1, "S5_EXACT_ONE_SCHEDULER_SLOT_REQUIRED");
  return result.rows[0] as Record<string, unknown>;
}

async function runCaseV1(mode: "COMPLETED" | "BLOCKED"): Promise<Record<string, unknown>> {
  await resetSchemaV1();
  await applySchedulerMigrationV1();

  const authority = await buildControlledAuthorityV1();
  const records = mode === "COMPLETED"
    ? authority.candidates
    : authority.candidates.filter((item) => !item.epistemic_class.includes("FUTURE"));
  const seeded = await seedControlledAuthorityV1(authority, records);
  await insertEvidenceV1(records);

  const through = new Date(Date.parse(authority.logicalTime) + 300_000).toISOString();
  const owner = `mcft-cap09-s5-${mode.toLowerCase()}`;
  const scheduler = new PostgresPersistentSequentialSchedulerAdapterV1(pool, {
    scope: authority.scope,
    schedule_start_logical_time: authority.logicalTime,
  });
  const preparation = new RestartBackfillStaleDetectionServiceV1(
    scheduler,
    new PostgresExpiredSlotRecoveryAdapterV1(pool, authority.scope),
    new PostgresEvidenceIngressAdapterV1(pool),
    seeded.nextTickRepository,
  );
  const canonicalPersistence = persistenceAdapterV1(
    seeded.runtimeRepository as PostgresRuntimeRepositoryV1,
    seeded.repository as PostgresForecastScenarioRecoveryRepositoryV1,
  );
  const canonical = new PostgresCap04ShadowOnlineCanonicalTickAdapterV1(
    pool,
    new PrepareNextTickInputServiceV1(seeded.nextTickRepository),
    seeded.runtimeRepository,
    canonicalPersistence,
  );
  const service = new ShadowOnlineCanonicalIntegrationServiceV1(
    preparation,
    scheduler,
    canonical,
  );

  const beforeFacts = await factCountV1();
  const result = await service.executeOldestDueTick({
    scope: authority.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...seeded.input,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(result.status, "CANONICAL_TICK_TERMINAL");
  if (result.status !== "CANONICAL_TICK_TERMINAL") {
    throw new Error("S5_CANONICAL_TICK_REQUIRED");
  }
  assert.equal(result.preparation.status, "CLAIM_READY");
  assert.equal(result.preparation.evidence.future_evidence_leakage, false);
  assert.deepEqual(
    result.preparation.evidence.selected.map((item) => item.evidence_ref).sort(),
    records.map((item) => item.source_record_id).sort(),
    "S5_S2_FROZEN_EVIDENCE_EXACT_SET_REQUIRED",
  );
  assert.equal(result.canonical.forecast_status, mode);
  assert.equal(result.canonical.g_write_count, 0);
  assert.equal(result.canonical.c_residual_count, 0);
  assert.equal(result.canonical.recommendation_count, 0);
  assert.equal(result.canonical.approval_count, 0);
  assert.equal(result.canonical.ao_act_count, 0);
  assert.equal(result.canonical.dispatch_count, 0);
  assert.equal(result.canonical.model_activation_count, 0);
  assert.equal(result.canonical.canonical_transaction_families.includes("A"), true);
  assert.equal(result.canonical.canonical_transaction_families.includes("F"), true);
  assert.equal(
    result.canonical.canonical_transaction_families.includes("B"),
    mode === "COMPLETED",
  );
  assert.equal(result.canonical.forecast_point_count, mode === "COMPLETED" ? 72 : 0);
  assert.equal(result.canonical.scenario_ref === null, mode === "BLOCKED");
  assert.equal(result.canonical.scenario_option_count, mode === "COMPLETED" ? 3 : 0);
  assert.equal(result.canonical.scenario_point_count, mode === "COMPLETED" ? 216 : 0);
  assert.equal(
    result.terminal_state,
    mode === "COMPLETED" ? "COMPLETED" : "DEGRADED",
  );

  for (const ref of [
    result.canonical.tick_ref,
    result.canonical.state_ref,
    result.canonical.forecast_ref,
    result.canonical.health_ref,
    result.canonical.checkpoint_ref,
  ]) {
    assert.equal(await factObjectCountV1(ref), 1, `S5_CANONICAL_OBJECT_READBACK:${ref}`);
  }
  if (result.canonical.scenario_ref) {
    assert.equal(await factObjectCountV1(result.canonical.scenario_ref), 1);
  }
  assert.equal(await forbiddenFactCountV1(), 0, "S5_FORBIDDEN_FACT_ZERO_REQUIRED");

  const terminal = await schedulerTerminalV1();
  assert.equal(terminal.slot_id, "O00");
  assert.equal(terminal.state, mode === "COMPLETED" ? "COMPLETED" : "DEGRADED");
  assert.equal(terminal.tick_ref, result.canonical.tick_ref);
  assert.equal(terminal.health_ref, result.canonical.health_ref);
  assert.equal(String(terminal.fencing_token), String(result.preparation.claim.fencing_token));

  const afterFirst = await factCountV1();
  assert.ok(afterFirst > beforeFacts, "S5_CANONICAL_FACT_DELTA_REQUIRED");
  const retry = await service.executeOldestDueTick({
    scope: authority.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...seeded.input,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(retry.status, "NO_CANONICAL_TICK");
  assert.equal(await factCountV1(), afterFirst, "S5_TERMINAL_SUCCESS_IMPLICIT_RETRY_FORBIDDEN");

  return {
    mode,
    scheduler_terminal_state: terminal.state,
    selected_evidence_refs: result.preparation.evidence.selected.map((item) => item.evidence_ref),
    canonical_transaction_families: result.canonical.canonical_transaction_families,
    tick_ref: result.canonical.tick_ref,
    state_ref: result.canonical.state_ref,
    forecast_ref: result.canonical.forecast_ref,
    forecast_status: result.canonical.forecast_status,
    forecast_point_count: result.canonical.forecast_point_count,
    scenario_ref: result.canonical.scenario_ref,
    scenario_option_count: result.canonical.scenario_option_count,
    scenario_point_count: result.canonical.scenario_point_count,
    health_ref: result.canonical.health_ref,
    checkpoint_ref: result.canonical.checkpoint_ref,
    next_logical_tick_time: result.canonical.next_logical_tick_time,
    canonical_fact_delta: afterFirst - beforeFacts,
    retry_canonical_fact_delta: 0,
    exact_frozen_evidence_reused: true,
    shared_scheduler_canonical_fence: true,
    forbidden_fact_count: 0,
    g_write_count: 0,
    action_creation_count: 0,
  };
}

async function main(): Promise<void> {
  const completed = await runCaseV1("COMPLETED");
  const blocked = await runCaseV1("BLOCKED");
  const output = {
    schema_version: "geox_mcft_cap09_s5_shadow_online_canonical_integration_db_result_v1",
    status: "PASS",
    completed,
    blocked,
    exact_s2_frozen_evidence_reused: true,
    scheduler_and_canonical_shared_lease_fence: true,
    online_state_forecast_health_readback: true,
    completed_blocked_separation_preserved: true,
    scenario_eligibility_preserved: true,
    residual_eligibility_preserved_without_new_c_commit: true,
    h_consumption_policy: "READ_ONLY_NONE_AVAILABLE",
    g_write_count: 0,
    recommendation_count: 0,
    approval_count: 0,
    ao_act_count: 0,
    dispatch_count: 0,
    model_activation_count: 0,
    public_http_writer_count: 0,
    background_scheduler_count: 0,
  };
  fs.mkdirSync(path.dirname(OUTPUT), { recursive: true });
  fs.writeFileSync(OUTPUT, `${JSON.stringify(output, null, 2)}\n`);
  console.log(JSON.stringify(output, null, 2));
}

main()
  .finally(async () => {
    await pool.end();
    await supportPool.end();
  })
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
