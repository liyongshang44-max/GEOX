// MCFT-CAP-09.S5 real PostgreSQL Shadow-online canonical integration acceptance.
// Destructive disposable-database only. Proves completed and blocked A/F paths,
// B eligibility, exact S2 frozen Evidence reuse, shared scheduler/canonical fence,
// terminal slot persistence, online readback, idempotent no-retry, and zero G/actions.

import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { Pool } from "pg";

import { PostgresForecastScenarioRecoveryRepositoryV1 } from "../../apps/server/src/persistence/twin_runtime/postgres_forecast_scenario_recovery_repository_v1.js";
import { PostgresRuntimeRepositoryV1 } from "../../apps/server/src/persistence/twin_runtime/postgres_runtime_repository_v1.js";
import { PostgresEvidenceIngressAdapterV1 } from "../../apps/server/src/runtime/twin_runtime/postgres_evidence_ingress_adapter_v1.js";
import { PostgresExpiredSlotRecoveryAdapterV1 } from "../../apps/server/src/runtime/twin_runtime/postgres_expired_slot_recovery_adapter_v1.js";
import {
  PostgresCap04ShadowOnlineCanonicalTickAdapterV1,
} from "../../apps/server/src/runtime/twin_runtime/postgres_cap04_shadow_online_canonical_tick_adapter_v1.js";
import {
  PostgresPersistentSequentialSchedulerAdapterV1,
} from "../../apps/server/src/runtime/twin_runtime/postgres_persistent_sequential_scheduler_adapter_v1.js";
import {
  RestartBackfillStaleDetectionServiceV1,
} from "../../apps/server/src/runtime/twin_runtime/restart_backfill_stale_detection_service_v1.js";
import {
  ShadowOnlineCanonicalIntegrationServiceV1,
} from "../../apps/server/src/runtime/twin_runtime/shadow_online_canonical_integration_service_v1.js";
import { PrepareNextTickInputServiceV1 } from "../../apps/server/src/runtime/twin_runtime/next_tick_input_service_v1.js";
import type { CanonicalReplayEvidenceRecordV1 } from "../../apps/server/src/runtime/twin_runtime/ports.js";
import {
  buildCap05EffectiveRuntimeConfigFromCap04FixtureV1,
} from "./mcft_cap_05_effective_runtime_config_fixture_v1.js";
import {
  buildCap05S8ForecastResidualFixtureV1,
} from "./mcft_cap_05_s8_forecast_residual_fixture_v1.js";
import {
  buildControlledAuthorityV1,
  persistenceAdapterV1,
  pool as supportPool,
  resetSchemaV1,
  seedControlledAuthorityV1,
} from "./mcft_cap09_s5_canonical_integration_support_v1.js";

if (process.env.MCFT_CAP09_S5_DESTRUCTIVE_ACCEPTANCE !== "1") {
  throw new Error("SET_MCFT_CAP09_S5_DESTRUCTIVE_ACCEPTANCE_1");
}
const databaseUrl = String(process.env.DATABASE_URL || "");
if (!databaseUrl) throw new Error("DATABASE_URL_REQUIRED");
const databaseName = new URL(databaseUrl).pathname.replace(/^\//, "").toLowerCase();
if (!/(mcft|cap09|s5|acceptance|test)/.test(databaseName)) {
  throw new Error("CAP09_S5_FRESH_ACCEPTANCE_DATABASE_REQUIRED");
}

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const OUTPUT = path.join(
  ROOT,
  "acceptance-output/MCFT_CAP_09_S5_SHADOW_ONLINE_CANONICAL_INTEGRATION_DB_RESULT.json",
);
const pool = new Pool({ connectionString: databaseUrl, max: 8 });

function factIdV1(record: CanonicalReplayEvidenceRecordV1): string {
  return `s5_evidence_${crypto.createHash("sha256")
    .update(`${record.source_record_id}|${record.source_record_hash}`)
    .digest("hex")
    .slice(0, 40)}`;
}

async function applySchedulerMigrationV1(): Promise<void> {
  const sql = fs.readFileSync(
    path.join(
      ROOT,
      "apps/server/db/migrations/2026_08_06_mcft_cap_09_s3_persistent_sequential_scheduler.sql",
    ),
    "utf8",
  );
  await pool.query(sql);
}

async function applyCap05MigrationV1(): Promise<void> {
  const sql = fs.readFileSync(
    path.join(
      ROOT,
      "apps/server/db/migrations/2026_07_14_mcft_cap_05_feedback_persistence.sql",
    ),
    "utf8",
  );
  await pool.query(sql);
}

async function insertEvidenceV1(
  records: readonly CanonicalReplayEvidenceRecordV1[],
): Promise<void> {
  for (const record of records) {
    await pool.query(
      `INSERT INTO facts(fact_id,occurred_at,source,record_json)
       VALUES($1,$2::timestamptz,$3,$4::jsonb)`,
      [
        factIdV1(record),
        record.available_to_runtime_at,
        "mcft-cap09-s5-shadow-online-acceptance",
        JSON.stringify({ type: record.record_type, payload: record }),
      ],
    );
  }
}

async function factObjectCountV1(objectId: string): Promise<number> {
  const result = await pool.query<{ n: number }>(
    `SELECT count(*)::int AS n
       FROM facts
      WHERE record_json->'payload'->>'object_id'=$1`,
    [objectId],
  );
  return Number(result.rows[0].n);
}

async function forbiddenFactCountV1(): Promise<number> {
  const result = await pool.query<{ n: number }>(
    `SELECT count(*)::int AS n
       FROM facts
      WHERE lower(record_json->>'type') ~
        '(recommendation|decision_candidate|approval|operation_plan|ao_act|dispatch|action_feedback|model_activation)'`,
  );
  return Number(result.rows[0].n);
}

async function factCountV1(): Promise<number> {
  return Number((await pool.query<{ n: number }>(
    "SELECT count(*)::int AS n FROM facts",
  )).rows[0].n);
}

async function schedulerTerminalV1(): Promise<Record<string, unknown>> {
  const result = await pool.query(
    `SELECT slot_id,state,tick_ref,health_ref,idempotency_key,fencing_token
       FROM twin_shadow_online_scheduler_slot_v1
      ORDER BY logical_time`,
  );
  assert.equal(result.rows.length, 1, "S5_EXACT_ONE_SCHEDULER_SLOT_REQUIRED");
  return result.rows[0] as Record<string, unknown>;
}

async function runCaseV1(
  mode: "COMPLETED" | "BLOCKED",
  runtimeProfile: "CAP04" | "CAP05" = "CAP04",
): Promise<Record<string, unknown>> {
  await resetSchemaV1();
  await applyCap05MigrationV1();
  await applySchedulerMigrationV1();

  const authority = await buildControlledAuthorityV1();
  const records = mode === "COMPLETED"
    ? authority.candidates
    : authority.candidates.filter((item) => !item.epistemic_class.includes("FUTURE"));
  const seeded = await seedControlledAuthorityV1(authority, records);
  let canonicalInput = seeded.input;
  if (runtimeProfile === "CAP05") {
    const cap05Config = buildCap05EffectiveRuntimeConfigFromCap04FixtureV1(
      authority.cap04Config,
    );
    await seeded.runtimeRepository.commitRuntimeConfig(cap05Config);
    canonicalInput = {
      ...seeded.input,
      runtime_config_ref: cap05Config.object_id,
      runtime_config_hash: cap05Config.determinism_hash,
    };
  }
  await insertEvidenceV1(records);

  const through = new Date(Date.parse(authority.logicalTime) + 300_000).toISOString();
  const owner = `mcft-cap09-s5-${runtimeProfile.toLowerCase()}-${mode.toLowerCase()}`;
  const scheduler = new PostgresPersistentSequentialSchedulerAdapterV1(pool, {
    scope: authority.scope,
    schedule_start_logical_time: authority.logicalTime,
  });
  const preparation = new RestartBackfillStaleDetectionServiceV1(
    scheduler,
    new PostgresExpiredSlotRecoveryAdapterV1(pool, authority.scope),
    new PostgresEvidenceIngressAdapterV1(pool),
    seeded.nextTickRepository,
  );
  const canonicalPersistence = persistenceAdapterV1(
    seeded.runtimeRepository as PostgresRuntimeRepositoryV1,
    seeded.repository as PostgresForecastScenarioRecoveryRepositoryV1,
  );
  const canonical = new PostgresCap04ShadowOnlineCanonicalTickAdapterV1(
    pool,
    new PrepareNextTickInputServiceV1(seeded.nextTickRepository),
    seeded.runtimeRepository,
    canonicalPersistence,
  );
  const service = new ShadowOnlineCanonicalIntegrationServiceV1(
    preparation,
    scheduler,
    canonical,
  );

  const beforeFacts = await factCountV1();
  const result = await service.executeOldestDueTick({
    scope: authority.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...canonicalInput,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(result.status, "CANONICAL_TICK_TERMINAL");
  if (result.status !== "CANONICAL_TICK_TERMINAL") {
    throw new Error("S5_CANONICAL_TICK_REQUIRED");
  }
  assert.equal(result.preparation.status, "CLAIM_READY");
  assert.equal(result.preparation.evidence.future_evidence_leakage, false);
  assert.deepEqual(
    result.preparation.evidence.selected.map((item) => item.evidence_ref).sort(),
    records.map((item) => item.source_record_id).sort(),
    "S5_S2_FROZEN_EVIDENCE_EXACT_SET_REQUIRED",
  );
  assert.equal(result.canonical.forecast_status, mode);
  assert.equal(result.canonical.g_write_count, 0);
  assert.equal(result.canonical.c_residual_count, 0);
  assert.equal(result.canonical.c_residual_ref, null);
  assert.equal(result.canonical.h_read_only_consumed, false);
  assert.equal(
    result.canonical.c_residual_attempted,
    runtimeProfile === "CAP05" && mode === "COMPLETED",
  );
  assert.equal(
    result.canonical.c_residual_disposition,
    runtimeProfile === "CAP05" && mode === "COMPLETED"
      ? "NO_ELIGIBLE_HISTORICAL_FORECAST"
      : runtimeProfile === "CAP05"
        ? "FORECAST_BLOCKED"
        : "RUNTIME_CONFIG_NOT_CAP05",
  );
  assert.equal(result.canonical.recommendation_count, 0);
  assert.equal(result.canonical.approval_count, 0);
  assert.equal(result.canonical.ao_act_count, 0);
  assert.equal(result.canonical.dispatch_count, 0);
  assert.equal(result.canonical.model_activation_count, 0);
  assert.equal(result.canonical.canonical_transaction_families.includes("A"), true);
  assert.equal(result.canonical.canonical_transaction_families.includes("F"), true);
  assert.equal(
    result.canonical.canonical_transaction_families.includes("B"),
    mode === "COMPLETED",
  );
  assert.equal(result.canonical.forecast_point_count, mode === "COMPLETED" ? 72 : 0);
  assert.equal(result.canonical.scenario_ref === null, mode === "BLOCKED");
  assert.equal(result.canonical.scenario_option_count, mode === "COMPLETED" ? 3 : 0);
  assert.equal(result.canonical.scenario_point_count, mode === "COMPLETED" ? 216 : 0);
  assert.equal(
    result.terminal_state,
    mode === "COMPLETED" ? "COMPLETED" : "DEGRADED",
  );

  for (const ref of [
    result.canonical.tick_ref,
    result.canonical.state_ref,
    result.canonical.forecast_ref,
    result.canonical.health_ref,
    result.canonical.checkpoint_ref,
  ]) {
    assert.equal(await factObjectCountV1(ref), 1, `S5_CANONICAL_OBJECT_READBACK:${ref}`);
  }
  if (result.canonical.scenario_ref) {
    assert.equal(await factObjectCountV1(result.canonical.scenario_ref), 1);
  }
  assert.equal(await forbiddenFactCountV1(), 0, "S5_FORBIDDEN_FACT_ZERO_REQUIRED");

  const terminal = await schedulerTerminalV1();
  assert.equal(terminal.slot_id, "O00");
  assert.equal(terminal.state, mode === "COMPLETED" ? "COMPLETED" : "DEGRADED");
  assert.equal(terminal.tick_ref, result.canonical.tick_ref);
  assert.equal(terminal.health_ref, result.canonical.health_ref);
  assert.equal(String(terminal.fencing_token), String(result.preparation.claim.fencing_token));

  const afterFirst = await factCountV1();
  assert.ok(afterFirst > beforeFacts, "S5_CANONICAL_FACT_DELTA_REQUIRED");
  const retry = await service.executeOldestDueTick({
    scope: authority.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...canonicalInput,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(retry.status, "NO_CANONICAL_TICK");
  assert.equal(await factCountV1(), afterFirst, "S5_TERMINAL_SUCCESS_IMPLICIT_RETRY_FORBIDDEN");

  return {
    mode,
    runtime_profile: runtimeProfile,
    scheduler_terminal_state: terminal.state,
    selected_evidence_refs: result.preparation.evidence.selected.map((item) => item.evidence_ref),
    canonical_transaction_families: result.canonical.canonical_transaction_families,
    tick_ref: result.canonical.tick_ref,
    state_ref: result.canonical.state_ref,
    forecast_ref: result.canonical.forecast_ref,
    forecast_status: result.canonical.forecast_status,
    forecast_point_count: result.canonical.forecast_point_count,
    scenario_ref: result.canonical.scenario_ref,
    scenario_option_count: result.canonical.scenario_option_count,
    scenario_point_count: result.canonical.scenario_point_count,
    health_ref: result.canonical.health_ref,
    checkpoint_ref: result.canonical.checkpoint_ref,
    next_logical_tick_time: result.canonical.next_logical_tick_time,
    canonical_fact_delta: afterFirst - beforeFacts,
    retry_canonical_fact_delta: 0,
    exact_frozen_evidence_reused: true,
    shared_scheduler_canonical_fence: true,
    forbidden_fact_count: 0,
    h_read_only_consumed: result.canonical.h_read_only_consumed,
    g_write_count: 0,
    c_residual_attempted: result.canonical.c_residual_attempted,
    c_residual_count: result.canonical.c_residual_count,
    c_residual_ref: result.canonical.c_residual_ref,
    c_residual_disposition: result.canonical.c_residual_disposition,
    action_creation_count: 0,
  };
}

async function runPositiveCap05ResidualThroughS5V1(): Promise<Record<string, unknown>> {
  await resetSchemaV1();
  await applyCap05MigrationV1();
  await applySchedulerMigrationV1();

  const fixture = await buildCap05S8ForecastResidualFixtureV1();
  const records = await fixture.outcome_evidence_source.loadCandidateRecords({
    scope: fixture.scope,
    logical_time: fixture.input.logical_time,
  });
  await insertEvidenceV1(records);

  const through = new Date(Date.parse(fixture.input.logical_time) + 300_000).toISOString();
  const owner = "mcft-cap09-s5-cap05-positive-residual";
  const scheduler = new PostgresPersistentSequentialSchedulerAdapterV1(pool, {
    scope: fixture.scope,
    schedule_start_logical_time: fixture.input.logical_time,
  });
  const preparation = new RestartBackfillStaleDetectionServiceV1(
    scheduler,
    new PostgresExpiredSlotRecoveryAdapterV1(pool, fixture.scope),
    new PostgresEvidenceIngressAdapterV1(pool),
    fixture.runtime,
  );
  const canonical = new PostgresCap04ShadowOnlineCanonicalTickAdapterV1(
    pool,
    new PrepareNextTickInputServiceV1(fixture.runtime),
    fixture.runtime,
    fixture.runtime,
    fixture.historical_source,
    fixture.residual_persistence,
  );
  const service = new ShadowOnlineCanonicalIntegrationServiceV1(
    preparation,
    scheduler,
    canonical,
  );

  const beforeFacts = await factCountV1();
  const result = await service.executeOldestDueTick({
    scope: fixture.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...fixture.input,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(result.status, "CANONICAL_TICK_TERMINAL");
  if (result.status !== "CANONICAL_TICK_TERMINAL") {
    throw new Error("S5_CAP05_POSITIVE_CANONICAL_TICK_REQUIRED");
  }
  assert.equal(result.preparation.status, "CLAIM_READY");
  assert.equal(result.preparation.evidence.future_evidence_leakage, false);
  assert.deepEqual(
    result.preparation.evidence.selected.map((item) => item.evidence_ref).sort(),
    records.map((item) => item.source_record_id).sort(),
    "S5_CAP05_POSITIVE_FROZEN_EVIDENCE_EXACT_SET_REQUIRED",
  );
  assert.equal(result.canonical.forecast_status, "COMPLETED");
  assert.equal(result.canonical.h_read_only_consumed, true);
  assert.equal(result.canonical.c_residual_attempted, true);
  assert.equal(result.canonical.c_residual_count, 1);
  assert.equal(result.canonical.c_residual_disposition, "COMMITTED");
  assert.equal(typeof result.canonical.c_residual_ref, "string");
  assert.equal(result.canonical.canonical_transaction_families.includes("C"), true);
  assert.equal(result.canonical.g_write_count, 0);
  assert.equal(result.canonical.recommendation_count, 0);
  assert.equal(result.canonical.approval_count, 0);
  assert.equal(result.canonical.ao_act_count, 0);
  assert.equal(result.canonical.dispatch_count, 0);
  assert.equal(result.canonical.model_activation_count, 0);
  assert.equal(result.terminal_state, "COMPLETED");
  assert.equal(fixture.historical_source.load_count, 1);
  assert.equal(fixture.residual_persistence.commit_count, 1);
  assert.equal(await forbiddenFactCountV1(), 0);

  const terminal = await schedulerTerminalV1();
  assert.equal(terminal.slot_id, "O00");
  assert.equal(terminal.state, "COMPLETED");
  assert.equal(terminal.tick_ref, result.canonical.tick_ref);
  assert.equal(terminal.health_ref, result.canonical.health_ref);
  assert.equal(String(terminal.fencing_token), String(result.preparation.claim.fencing_token));

  const afterFirst = await factCountV1();
  assert.equal(afterFirst, beforeFacts, "S5_CAP05_POSITIVE_CANONICAL_FACTS_MUST_REMAIN_IN_INJECTED_FIXTURE");
  const retry = await service.executeOldestDueTick({
    scope: fixture.scope,
    through_logical_time: through,
    lease_owner: owner,
    lease_duration_seconds: 300,
    terminal_at: through,
    canonical_input: {
      ...fixture.input,
      lease_owner: owner,
      lease_duration_seconds: 300,
    },
  });
  assert.equal(retry.status, "NO_CANONICAL_TICK");
  assert.equal(fixture.residual_persistence.commit_count, 1);

  return {
    mode: "COMPLETED",
    runtime_profile: "CAP05",
    scheduler_terminal_state: terminal.state,
    selected_evidence_refs: result.preparation.evidence.selected.map((item) => item.evidence_ref),
    canonical_transaction_families: result.canonical.canonical_transaction_families,
    tick_ref: result.canonical.tick_ref,
    state_ref: result.canonical.state_ref,
    forecast_ref: result.canonical.forecast_ref,
    forecast_status: result.canonical.forecast_status,
    scenario_ref: result.canonical.scenario_ref,
    health_ref: result.canonical.health_ref,
    checkpoint_ref: result.canonical.checkpoint_ref,
    exact_frozen_evidence_reused: true,
    shared_scheduler_canonical_fence: true,
    h_read_only_consumed: true,
    c_residual_attempted: true,
    c_residual_count: 1,
    c_residual_ref: result.canonical.c_residual_ref,
    c_residual_disposition: result.canonical.c_residual_disposition,
    s5_adapter_positive_c_composition_proven: true,
    production_postgresql_c_persistence_proven_separately: true,
    g_write_count: 0,
    action_creation_count: 0,
    forbidden_fact_count: 0,
  };
}

async function main(): Promise<void> {
  const completed = await runCaseV1("COMPLETED");
  const blocked = await runCaseV1("BLOCKED");
  const cap05NoResidual = await runCaseV1("COMPLETED", "CAP05");
  const cap05PositiveResidual = await runPositiveCap05ResidualThroughS5V1();
  const output = {
    schema_version: "geox_mcft_cap09_s5_shadow_online_canonical_integration_db_result_v1",
    status: "PASS",
    completed,
    blocked,
    cap05_no_residual: cap05NoResidual,
    cap05_positive_residual: cap05PositiveResidual,
    exact_s2_frozen_evidence_reused: true,
    scheduler_and_canonical_shared_lease_fence: true,
    online_state_forecast_health_readback: true,
    completed_blocked_separation_preserved: true,
    scenario_eligibility_preserved: true,
    residual_no_match_is_explicit_and_non_fatal: true,
    cap05_residual_adapter_invoked: cap05NoResidual.c_residual_attempted === true,
    positive_c_composition_through_s5_adapter: cap05PositiveResidual.c_residual_count === 1,
    positive_c_commit_proven_by_existing_cap05_postgresql_acceptance: true,
    h_consumption_policy: "READ_ONLY_ONLY_WHEN_SELECTED_HISTORICAL_FORECAST_EXISTS",
    g_write_count: 0,
    recommendation_count: 0,
    approval_count: 0,
    ao_act_count: 0,
    dispatch_count: 0,
    model_activation_count: 0,
    public_http_writer_count: 0,
    background_scheduler_count: 0,
  };
  fs.mkdirSync(path.dirname(OUTPUT), { recursive: true });
  fs.writeFileSync(OUTPUT, `${JSON.stringify(output, null, 2)}\n`);
  console.log(JSON.stringify(output, null, 2));
}

main()
  .finally(async () => {
    await pool.end();
    await supportPool.end();
  })
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
